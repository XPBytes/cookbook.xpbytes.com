Imagemagick CHANGELOG
=====================

v0.2.3 (2014-02-25)
-------------------
[COOK-3748] - Add support for Amazon Linux & Mac OS X


v0.2.2
----------
- Fixes COOK-662
