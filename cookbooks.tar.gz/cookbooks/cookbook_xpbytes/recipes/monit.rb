package 'Install Monit 1:5.16-2' do
  package_name 'monit'
  version '1:5.16-2'
  options '--allow-downgrades'
end
